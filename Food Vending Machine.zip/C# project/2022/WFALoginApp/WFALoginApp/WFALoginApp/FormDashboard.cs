﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFALoginApp
{
    public partial class FormDashboard: Form
    {
        private DataAccess Da { get; set; }
        public FormDashboard()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            
            this.PopulateGridView();
            this.dgvMovie.ClearSelection();
        }

        private void PopulateGridView(string sql = "select * from Movie;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvMovie.AutoGenerateColumns = false;
            this.dgvMovie.DataSource = ds.Tables[0];
        }

        private void btnShowInfo_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sql = "select * from Movie where Genre = '" + this.txtSearch.Text + "';";
            this.PopulateGridView(sql);
        }

        private void txtAutoSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from Movie where Title like '" + this.txtAutoSearch.Text + "%';";
            this.PopulateGridView(sql);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!IsValidToSave())
            {
                MessageBox.Show("Please fill all the information", "Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            try
            {
                var sql = "select * from Movie where Id = '" + this.txtId.Text + "';";
                DataTable dt = this.Da.ExecuteQueryTable(sql);
                if (dt.Rows.Count == 1)
                {
                    //update
                    sql = @"update Movie
                            set Title = '" + this.txtTitle.Text + @"',
                            IMDB = " + this.txtIMDB.Text + @",
                            Income = " + this.txtIncome.Text + @",
                            ReleaseDate = '" + this.dtpReleaseDate.Text + @"',
                            Genre = '" + this.cmbGenre.Text + @"'
                            where Id = '" + this.txtId.Text + "';";
                    var rowCount = this.Da.ExecuteDMLQuery(sql);

                    if (rowCount == 1)
                    {
                        MessageBox.Show("Data update operation completed.");
                    }
                    else
                    {
                        MessageBox.Show("Data update operation failed.");
                    }
                }
                else 
                {
                    //insert
                    sql = @"insert into Movie values('" + this.txtId.Text + "', '" + this.txtTitle.Text + "', " + this.txtIMDB.Text + ", " + this.txtIncome.Text + ", '" + this.dtpReleaseDate.Text + "', '" + this.cmbGenre.Text + "');";
                    var rowCount = this.Da.ExecuteDMLQuery(sql);

                    if (rowCount == 1)
                    {
                        MessageBox.Show("Data insertion operation completed.");
                    }
                    else
                    {
                        MessageBox.Show("Data insertion operation failed.");
                    }
                }

                this.RefreshContent();
                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured, please try again later. Error msg: " + exc.Message);
            }            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (this.dgvMovie.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please select a row first to delete", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                return;
            }    
            try
            {
                if (this.dgvMovie.SelectedRows.Count  > 0)
                {
                    MessageBox.Show("Please select a row first to delete", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                    return;
                }
                var id = this.dgvMovie.CurrentRow.Cells[0].Value.ToString();
                var title = this.dgvMovie.CurrentRow.Cells[1].Value.ToString();

                var sql = "delete from Movie where Id = '" + id + "';";
                var rowCount = this.Da.ExecuteDMLQuery(sql);

                if (rowCount == 1)
                {
                    MessageBox.Show(title + " has been deleted from list.");
                }
                else
                {
                    MessageBox.Show("Data deletion operation failed.");
                }
                this.PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured, please try again later. Error msg: " + exc.Message);
            }            
        }

        private void FormDashboard_Load(object sender, EventArgs e)
        {
            this.dgvMovie.ClearSelection();
            this.AutoId();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.RefreshContent();
        }

        private void RefreshContent()
        {
            this.txtId.Clear();
            this.txtTitle.Clear();
            this.txtIMDB.Clear();
            this.txtIncome.Clear();
            this.dtpReleaseDate.Text = "";
            this.cmbGenre.SelectedIndex = -1;
            this.AutoId();
        }

        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtId.Text) || String.IsNullOrEmpty(this.txtTitle.Text) ||
                String.IsNullOrEmpty(this.txtIMDB.Text) || String.IsNullOrEmpty(this.txtIncome.Text) ||
                String.IsNullOrEmpty(this.dtpReleaseDate.Text) || String.IsNullOrEmpty(this.cmbGenre.Text))
            {
                return false;
            }
            else
                return true;
        }

        private void dgvMovie_DoubleClick(object sender, EventArgs e)
        {
            this.txtId.Text = this.dgvMovie.CurrentRow.Cells["Id"].Value.ToString();
            this.txtTitle.Text = this.dgvMovie.CurrentRow.Cells["Title"].Value.ToString();
            this.txtIMDB.Text = this.dgvMovie.CurrentRow.Cells["IMDB"].Value.ToString();
            this.txtIncome.Text = this.dgvMovie.CurrentRow.Cells["Income"].Value.ToString();
            this.dtpReleaseDate.Text = this.dgvMovie.CurrentRow.Cells["ReleaseDate"].Value.ToString();
            this.cmbGenre.Text = this.dgvMovie.CurrentRow.Cells["Genre"].Value.ToString();
        }

        private void AutoId() 
        {
            var sql = "select * from Movie order by Id desc;";
            var dt = this.Da.ExecuteQueryTable(sql);

            var lastId = dt.Rows[0][0].ToString();
            string[] temp = lastId.Split('-');
            int no = Convert.ToInt32(temp[1]);
            string newId = "m-" + (++no).ToString("d3");
            this.txtId.Text = newId;

            List<int> a = new List<int>();
            a.Add(34);
            a.Add(100);
            a.Add(89);
        }
    }
}
