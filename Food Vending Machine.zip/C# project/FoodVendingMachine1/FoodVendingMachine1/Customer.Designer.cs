﻿
namespace FoodVendingMachine1
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pbCocaCola = new System.Windows.Forms.PictureBox();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.pbPotato = new System.Windows.Forms.PictureBox();
            this.pbMangoBar = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pbLays = new System.Windows.Forms.PictureBox();
            this.pbMountainDew = new System.Windows.Forms.PictureBox();
            this.pbPepsi = new System.Windows.Forms.PictureBox();
            this.pbSnackess = new System.Windows.Forms.PictureBox();
            this.pbDairyMilk = new System.Windows.Forms.PictureBox();
            this.btnLays = new System.Windows.Forms.Button();
            this.btnSnackers = new System.Windows.Forms.Button();
            this.btnPrice = new System.Windows.Forms.Button();
            this.btnDew = new System.Windows.Forms.Button();
            this.btnDairy = new System.Windows.Forms.Button();
            this.btnCola = new System.Windows.Forms.Button();
            this.btnPotato = new System.Windows.Forms.Button();
            this.lblProduct7 = new System.Windows.Forms.Label();
            this.lblProduct6 = new System.Windows.Forms.Label();
            this.lblProduct4 = new System.Windows.Forms.Label();
            this.lblProduct5 = new System.Windows.Forms.Label();
            this.lblProduct3 = new System.Windows.Forms.Label();
            this.lblProduct2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblProduct1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocaCola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPotato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMangoBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLays)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMountainDew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPepsi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSnackess)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDairyMilk)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1252, 739);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pbCocaCola);
            this.panel2.Controls.Add(this.btnMainMenu);
            this.panel2.Controls.Add(this.pbPotato);
            this.panel2.Controls.Add(this.pbMangoBar);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pbLays);
            this.panel2.Controls.Add(this.pbMountainDew);
            this.panel2.Controls.Add(this.pbPepsi);
            this.panel2.Controls.Add(this.pbSnackess);
            this.panel2.Controls.Add(this.pbDairyMilk);
            this.panel2.Controls.Add(this.btnLays);
            this.panel2.Controls.Add(this.btnSnackers);
            this.panel2.Controls.Add(this.btnPrice);
            this.panel2.Controls.Add(this.btnDew);
            this.panel2.Controls.Add(this.btnDairy);
            this.panel2.Controls.Add(this.btnCola);
            this.panel2.Controls.Add(this.btnPotato);
            this.panel2.Controls.Add(this.lblProduct7);
            this.panel2.Controls.Add(this.lblProduct6);
            this.panel2.Controls.Add(this.lblProduct4);
            this.panel2.Controls.Add(this.lblProduct5);
            this.panel2.Controls.Add(this.lblProduct3);
            this.panel2.Controls.Add(this.lblProduct2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblProduct1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1252, 739);
            this.panel2.TabIndex = 1;
            // 
            // pbCocaCola
            // 
            this.pbCocaCola.Location = new System.Drawing.Point(390, 87);
            this.pbCocaCola.Name = "pbCocaCola";
            this.pbCocaCola.Size = new System.Drawing.Size(144, 180);
            this.pbCocaCola.TabIndex = 37;
            this.pbCocaCola.TabStop = false;
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.DarkOrange;
            this.btnMainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.Location = new System.Drawing.Point(12, 688);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(128, 39);
            this.btnMainMenu.TabIndex = 36;
            this.btnMainMenu.Text = "Main Manu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click_1);
            // 
            // pbPotato
            // 
            this.pbPotato.Location = new System.Drawing.Point(147, 87);
            this.pbPotato.Name = "pbPotato";
            this.pbPotato.Size = new System.Drawing.Size(160, 180);
            this.pbPotato.TabIndex = 35;
            this.pbPotato.TabStop = false;
            // 
            // pbMangoBar
            // 
            this.pbMangoBar.Location = new System.Drawing.Point(903, 416);
            this.pbMangoBar.Name = "pbMangoBar";
            this.pbMangoBar.Size = new System.Drawing.Size(158, 157);
            this.pbMangoBar.TabIndex = 33;
            this.pbMangoBar.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(941, 628);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 35);
            this.button1.TabIndex = 32;
            this.button1.Text = "Buy";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OliveDrab;
            this.label2.Location = new System.Drawing.Point(879, 596);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 21);
            this.label2.TabIndex = 31;
            this.label2.Text = "MangoBar Price 10Tk.";
            // 
            // pbLays
            // 
            this.pbLays.Location = new System.Drawing.Point(903, 87);
            this.pbLays.Name = "pbLays";
            this.pbLays.Size = new System.Drawing.Size(160, 180);
            this.pbLays.TabIndex = 30;
            this.pbLays.TabStop = false;
            // 
            // pbMountainDew
            // 
            this.pbMountainDew.Location = new System.Drawing.Point(649, 416);
            this.pbMountainDew.Name = "pbMountainDew";
            this.pbMountainDew.Size = new System.Drawing.Size(158, 157);
            this.pbMountainDew.TabIndex = 28;
            this.pbMountainDew.TabStop = false;
            // 
            // pbPepsi
            // 
            this.pbPepsi.Location = new System.Drawing.Point(390, 403);
            this.pbPepsi.Name = "pbPepsi";
            this.pbPepsi.Size = new System.Drawing.Size(144, 186);
            this.pbPepsi.TabIndex = 27;
            this.pbPepsi.TabStop = false;
            // 
            // pbSnackess
            // 
            this.pbSnackess.Location = new System.Drawing.Point(158, 403);
            this.pbSnackess.Name = "pbSnackess";
            this.pbSnackess.Size = new System.Drawing.Size(159, 186);
            this.pbSnackess.TabIndex = 26;
            this.pbSnackess.TabStop = false;
            // 
            // pbDairyMilk
            // 
            this.pbDairyMilk.Location = new System.Drawing.Point(620, 87);
            this.pbDairyMilk.Name = "pbDairyMilk";
            this.pbDairyMilk.Size = new System.Drawing.Size(161, 180);
            this.pbDairyMilk.TabIndex = 24;
            this.pbDairyMilk.TabStop = false;
            // 
            // btnLays
            // 
            this.btnLays.BackColor = System.Drawing.Color.Lime;
            this.btnLays.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLays.Location = new System.Drawing.Point(946, 331);
            this.btnLays.Name = "btnLays";
            this.btnLays.Size = new System.Drawing.Size(70, 35);
            this.btnLays.TabIndex = 21;
            this.btnLays.Text = "Buy";
            this.btnLays.UseVisualStyleBackColor = false;
            this.btnLays.Click += new System.EventHandler(this.btnLays_Click);
            // 
            // btnSnackers
            // 
            this.btnSnackers.BackColor = System.Drawing.Color.Lime;
            this.btnSnackers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSnackers.Location = new System.Drawing.Point(192, 637);
            this.btnSnackers.Name = "btnSnackers";
            this.btnSnackers.Size = new System.Drawing.Size(70, 35);
            this.btnSnackers.TabIndex = 20;
            this.btnSnackers.Text = "Buy";
            this.btnSnackers.UseVisualStyleBackColor = false;
            this.btnSnackers.Click += new System.EventHandler(this.btnSnackers_Click);
            // 
            // btnPrice
            // 
            this.btnPrice.BackColor = System.Drawing.Color.Lime;
            this.btnPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrice.Location = new System.Drawing.Point(402, 637);
            this.btnPrice.Name = "btnPrice";
            this.btnPrice.Size = new System.Drawing.Size(70, 35);
            this.btnPrice.TabIndex = 19;
            this.btnPrice.Text = "Buy";
            this.btnPrice.UseVisualStyleBackColor = false;
            this.btnPrice.Click += new System.EventHandler(this.btnPrice_Click);
            // 
            // btnDew
            // 
            this.btnDew.BackColor = System.Drawing.Color.Lime;
            this.btnDew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDew.Location = new System.Drawing.Point(695, 632);
            this.btnDew.Name = "btnDew";
            this.btnDew.Size = new System.Drawing.Size(70, 35);
            this.btnDew.TabIndex = 18;
            this.btnDew.Text = "Buy";
            this.btnDew.UseVisualStyleBackColor = false;
            this.btnDew.Click += new System.EventHandler(this.btnDew_Click);
            // 
            // btnDairy
            // 
            this.btnDairy.BackColor = System.Drawing.Color.Lime;
            this.btnDairy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDairy.Location = new System.Drawing.Point(681, 331);
            this.btnDairy.Name = "btnDairy";
            this.btnDairy.Size = new System.Drawing.Size(70, 35);
            this.btnDairy.TabIndex = 17;
            this.btnDairy.Text = "Buy";
            this.btnDairy.UseVisualStyleBackColor = false;
            this.btnDairy.Click += new System.EventHandler(this.btnDairy_Click);
            // 
            // btnCola
            // 
            this.btnCola.BackColor = System.Drawing.Color.Lime;
            this.btnCola.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCola.Location = new System.Drawing.Point(417, 331);
            this.btnCola.Name = "btnCola";
            this.btnCola.Size = new System.Drawing.Size(70, 35);
            this.btnCola.TabIndex = 11;
            this.btnCola.Text = "Buy";
            this.btnCola.UseVisualStyleBackColor = false;
            this.btnCola.Click += new System.EventHandler(this.btnCola_Click);
            // 
            // btnPotato
            // 
            this.btnPotato.BackColor = System.Drawing.Color.Lime;
            this.btnPotato.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPotato.ForeColor = System.Drawing.Color.Black;
            this.btnPotato.Location = new System.Drawing.Point(183, 331);
            this.btnPotato.Name = "btnPotato";
            this.btnPotato.Size = new System.Drawing.Size(75, 35);
            this.btnPotato.TabIndex = 10;
            this.btnPotato.Text = "Buy";
            this.btnPotato.UseVisualStyleBackColor = false;
            this.btnPotato.Click += new System.EventHandler(this.btnPotato_Click_1);
            // 
            // lblProduct7
            // 
            this.lblProduct7.AutoSize = true;
            this.lblProduct7.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct7.ForeColor = System.Drawing.Color.OliveDrab;
            this.lblProduct7.Location = new System.Drawing.Point(616, 596);
            this.lblProduct7.Name = "lblProduct7";
            this.lblProduct7.Size = new System.Drawing.Size(219, 21);
            this.lblProduct7.TabIndex = 9;
            this.lblProduct7.Text = "MountenDew Price 30Tk.";
            // 
            // lblProduct6
            // 
            this.lblProduct6.AutoSize = true;
            this.lblProduct6.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblProduct6.Location = new System.Drawing.Point(357, 596);
            this.lblProduct6.Name = "lblProduct6";
            this.lblProduct6.Size = new System.Drawing.Size(157, 21);
            this.lblProduct6.TabIndex = 8;
            this.lblProduct6.Text = "Pepsi Price 30Tk.";
            // 
            // lblProduct4
            // 
            this.lblProduct4.AutoSize = true;
            this.lblProduct4.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lblProduct4.Location = new System.Drawing.Point(910, 297);
            this.lblProduct4.Name = "lblProduct4";
            this.lblProduct4.Size = new System.Drawing.Size(151, 21);
            this.lblProduct4.TabIndex = 7;
            this.lblProduct4.Text = "Lays Price 10Tk.";
            // 
            // lblProduct5
            // 
            this.lblProduct5.AutoSize = true;
            this.lblProduct5.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblProduct5.Location = new System.Drawing.Point(129, 596);
            this.lblProduct5.Name = "lblProduct5";
            this.lblProduct5.Size = new System.Drawing.Size(189, 21);
            this.lblProduct5.TabIndex = 6;
            this.lblProduct5.Text = "Snackers Price 50Tk.";
            // 
            // lblProduct3
            // 
            this.lblProduct3.AutoSize = true;
            this.lblProduct3.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblProduct3.Location = new System.Drawing.Point(616, 297);
            this.lblProduct3.Name = "lblProduct3";
            this.lblProduct3.Size = new System.Drawing.Size(191, 21);
            this.lblProduct3.TabIndex = 5;
            this.lblProduct3.Text = "DairyMilk Price 25Tk.";
            // 
            // lblProduct2
            // 
            this.lblProduct2.AutoSize = true;
            this.lblProduct2.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct2.ForeColor = System.Drawing.Color.Red;
            this.lblProduct2.Location = new System.Drawing.Point(357, 297);
            this.lblProduct2.Name = "lblProduct2";
            this.lblProduct2.Size = new System.Drawing.Size(188, 21);
            this.lblProduct2.TabIndex = 4;
            this.lblProduct2.Text = "CocaCola price 30Tk.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(180, 350);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 17);
            this.label3.TabIndex = 3;
            // 
            // lblProduct1
            // 
            this.lblProduct1.AutoSize = true;
            this.lblProduct1.Font = new System.Drawing.Font("Britannic Bold", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduct1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lblProduct1.Location = new System.Drawing.Point(129, 297);
            this.lblProduct1.Name = "lblProduct1";
            this.lblProduct1.Size = new System.Drawing.Size(166, 21);
            this.lblProduct1.TabIndex = 2;
            this.lblProduct1.Text = "Potato Price 10Tk.";
            // 
            // label1
            // 
            this.label1.AllowDrop = true;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Ravie", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(229, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(731, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome To Food Vending Machine";
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 739);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Customer";
            this.Text = "Customer";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCocaCola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPotato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMangoBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLays)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMountainDew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPepsi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSnackess)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDairyMilk)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pbCocaCola;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.PictureBox pbPotato;
        private System.Windows.Forms.PictureBox pbMangoBar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbLays;
        private System.Windows.Forms.PictureBox pbMountainDew;
        private System.Windows.Forms.PictureBox pbPepsi;
        private System.Windows.Forms.PictureBox pbSnackess;
        private System.Windows.Forms.PictureBox pbDairyMilk;
        private System.Windows.Forms.Button btnLays;
        private System.Windows.Forms.Button btnSnackers;
        private System.Windows.Forms.Button btnPrice;
        private System.Windows.Forms.Button btnDew;
        private System.Windows.Forms.Button btnDairy;
        private System.Windows.Forms.Button btnCola;
        private System.Windows.Forms.Button btnPotato;
        private System.Windows.Forms.Label lblProduct7;
        private System.Windows.Forms.Label lblProduct6;
        private System.Windows.Forms.Label lblProduct4;
        private System.Windows.Forms.Label lblProduct5;
        private System.Windows.Forms.Label lblProduct3;
        private System.Windows.Forms.Label lblProduct2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblProduct1;
        private System.Windows.Forms.Label label1;
    }
}