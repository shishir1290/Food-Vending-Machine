﻿
namespace FoodVendingMachine1
{
    partial class Editor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnMainManu = new System.Windows.Forms.Button();
            this.lblAdminWelcome = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnNextStap1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMainManu);
            this.panel1.Controls.Add(this.lblAdminWelcome);
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Controls.Add(this.btnNextStap1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 1;
            // 
            // btnMainManu
            // 
            this.btnMainManu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnMainManu.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainManu.Location = new System.Drawing.Point(84, 371);
            this.btnMainManu.Name = "btnMainManu";
            this.btnMainManu.Size = new System.Drawing.Size(149, 36);
            this.btnMainManu.TabIndex = 8;
            this.btnMainManu.Text = "Main Manu";
            this.btnMainManu.UseVisualStyleBackColor = false;
            this.btnMainManu.Click += new System.EventHandler(this.btnMainManu_Click);
            // 
            // lblAdminWelcome
            // 
            this.lblAdminWelcome.AutoSize = true;
            this.lblAdminWelcome.Font = new System.Drawing.Font("Segoe Script", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminWelcome.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblAdminWelcome.Location = new System.Drawing.Point(235, 33);
            this.lblAdminWelcome.Name = "lblAdminWelcome";
            this.lblAdminWelcome.Size = new System.Drawing.Size(194, 57);
            this.lblAdminWelcome.TabIndex = 7;
            this.lblAdminWelcome.Text = "Welcome ";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Lavender;
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 27;
            this.listBox1.Items.AddRange(new object[] {
            "Edit Product Information",
            "Switch Off the matchine"});
            this.listBox1.Location = new System.Drawing.Point(195, 175);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(312, 137);
            this.listBox1.TabIndex = 6;
            // 
            // btnNextStap1
            // 
            this.btnNextStap1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnNextStap1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNextStap1.Location = new System.Drawing.Point(501, 381);
            this.btnNextStap1.Name = "btnNextStap1";
            this.btnNextStap1.Size = new System.Drawing.Size(149, 36);
            this.btnNextStap1.TabIndex = 5;
            this.btnNextStap1.Text = "Next";
            this.btnNextStap1.UseVisualStyleBackColor = false;
            this.btnNextStap1.Click += new System.EventHandler(this.btnNextStap1_Click);
            // 
            // Editor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Editor";
            this.Text = "Editor";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblAdminWelcome;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnNextStap1;
        private System.Windows.Forms.Button btnMainManu;
    }
}