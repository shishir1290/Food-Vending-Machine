﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class Purchase : Form
    {
        public Purchase()
        {
            InitializeComponent();
        }

        private void Purchase_Load(object sender, EventArgs e)
        {
            this.txtReturn.Text = "Thanks you for use our matchine.\nYour desired refundable money: " + Order.FinalAmount + " Tk";
            txtReturn.SelectionStart = 0;
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            LogIn ln = new LogIn();
            ln.Show();
            this.Hide();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Customer cus = new Customer();
            cus.Show();
            this.Hide();
        }
    }
}
