﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class Moderator : Form
    {
        public Moderator()
        {
            InitializeComponent();
        }

        private void btnNextStap1_Click(object sender, EventArgs e)
        {
            StringBuilder stringb = new StringBuilder();
            foreach (var item in listBox1.Items)
            {
                stringb.Append(item.ToString());
                stringb.Append(" ");
            }
            string EUI = listBox1.SelectedItem.ToString();
            
            if (EUI == "Edit Product Information")
            {
                Product PInfo = new Product();
                PInfo.Show();
                this.Hide();
            }
            if (EUI == "Switch On the matchine")
            {
                Customer product = new Customer();
                product.Show();
                this.Hide();
            }
            if (EUI == "Switch Off the matchine")
            {
                CloseProgram cp = new CloseProgram();
                cp.Show();
                this.Hide();
            }
        }
    }
}
