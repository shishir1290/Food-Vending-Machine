﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void btnNextStap1_Click_1(object sender, EventArgs e)
        {
            StringBuilder stringb = new StringBuilder();
            foreach (var item in listBox1.Items)
            {
                stringb.Append(item.ToString());
                stringb.Append(" ");
            }
            string EUI = listBox1.SelectedItem.ToString();
            if (EUI == "Edit User Information")
            {
                UserInformation UInfo = new UserInformation();
                UInfo.Show();
                this.Hide();
            }
            if (EUI == "Edit Product Information")
            {
                Product PInfo = new Product();
                PInfo.Show();
                this.Hide();
            }
            if (EUI == "Switch On the matching")
            {
                Customer cust = new Customer();
                cust.Show();
                this.Hide();
            }
            if (EUI == "Switch Off the matchine")
            {
                CloseProgram cp = new CloseProgram();
                cp.Show();
                this.Hide();
            }
        }

        private void lblAdminWelcome_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
