﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class UserInformation : Form
    {
        private Info Da { get; set; }

        public UserInformation()
        {
            InitializeComponent();
            this.Da = new Info();

            this.PopulateGridView();
            this.dgvUserInfo.ClearSelection();
        }

        private void PopulateGridView(string sql = "select * from UserInfo;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvUserInfo.AutoGenerateColumns = false;
            this.dgvUserInfo.DataSource = ds.Tables[0];
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        private bool IsValidToSaveData()
        {
            if (String.IsNullOrEmpty(this.txtUserId.Text) || 
                String.IsNullOrEmpty(this.txtName.Text) || String.IsNullOrEmpty(this.txtPassword.Text) ||
                String.IsNullOrEmpty(this.cmbRole.Text) || String.IsNullOrWhiteSpace(this.txtUserId.Text))
            {
                return false;
            }
            else
                return true;
        }

        private void AutoIdGenerate()
        {
            var sql = "select * from UserInfo order by Id desc;";
            var dt = this.Da.ExecuteQueryTable(sql);

            var lastId = dt.Rows[0][0].ToString();
            string[] temp = lastId.Split('-');
            int no = Convert.ToInt32(temp[1]);
            string newId = "20-" + (++no).ToString("d3") + "-2";
            this.txtUserId.Text = newId;
        }

        private void RefreshContent()
        {
            this.txtUserId.Clear();
            this.txtName.Clear();
            this.txtPassword.Clear();
            this.cmbRole.SelectedIndex = -1;
            this.txtAutoUserSearch.Clear();
            this.AutoIdGenerate();
        }

        private void txtAutoSearch_TextChanged_1(object sender, EventArgs e)
        {
            var sql = "select * from UserInfo where Name like '" + this.txtAutoUserSearch.Text + "%' or Id like '"+this.txtAutoUserSearch.Text+"%';";
            this.PopulateGridView(sql);
        }

        private void dgvUserInfo_DoubleClick(object sender, EventArgs e)
        {
            this.txtUserId.Text = this.dgvUserInfo.CurrentRow.Cells["Id"].Value.ToString();
            this.txtName.Text = this.dgvUserInfo.CurrentRow.Cells[1].Value.ToString();
            this.txtPassword.Text = this.dgvUserInfo.CurrentRow.Cells[2].Value.ToString();
            this.cmbRole.Text = this.dgvUserInfo.CurrentRow.Cells[3].Value.ToString();
        }
        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtUserId.Text) ||
                String.IsNullOrEmpty(this.txtName.Text) || String.IsNullOrEmpty(this.txtPassword.Text) ||
                String.IsNullOrEmpty(this.cmbRole.Text) || String.IsNullOrWhiteSpace(this.txtUserId.Text))
            {
                return false;
            }
            else
                return true;
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            if (!IsValidToSave())
            {
                MessageBox.Show("Please fill all the information", "Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            try
            {
                var query = "select * from UserInfo where Id = '" + this.txtUserId.Text + "';";
                var ds = this.Da.ExecuteQuery(query);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    var sql = @"update UserInfo
                                set 
                                Name = " + this.txtName.Text + @", 
                                Password = " + this.txtPassword.Text + @",
                                Role = '" + this.cmbRole.Text + @"'
                                where Id = '" + this.txtUserId.Text + "';";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data updated successfully");
                    else
                        MessageBox.Show("Data upgradation failed");
                }
                else
                {
                    //insert
                    var sql = @"insert into UserInfo values('" + this.txtUserId.Text + "','" + this.txtName.Text + "'," + this.txtPassword.Text + ",'" + this.cmbRole.Text + "');";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data insertion successfull");
                    else
                        MessageBox.Show("Data insertion failed");
                }

                this.PopulateGridView();
                this.RefreshContent();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (this.dgvUserInfo.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please select a row first to delete", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                return;
            }
            if (DialogResult.Yes == MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                try
                {

                    var id = this.dgvUserInfo.CurrentRow.Cells[0].Value.ToString();
                    var title = this.dgvUserInfo.CurrentRow.Cells[1].Value.ToString();

                    var sql = "delete from userInfo where Id = '" + id + "';";
                    var rowCount = this.Da.ExecuteDMLQuery(sql);

                    if (rowCount == 1)
                    {
                        MessageBox.Show(title + " has been deleted from list.");
                    }
                    else
                    {
                        MessageBox.Show("Data deletion operation failed.");
                    }
                    this.PopulateGridView();
                }
                catch (Exception exc)
                {
                    MessageBox.Show("An error has occured, please try again later. Error msg: " + exc.Message);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.RefreshContent();
        }

        private void UserInformation_Load(object sender, EventArgs e)
        {
            this.dgvUserInfo.ClearSelection();
            this.AutoIdGenerate();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            LogIn ln = new LogIn();
            ln.Show();
            this.Hide();
        }
    }
}
