﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class Order : Form
    {
        public static string FinalAmount = "";
        public Order()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
           
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            
        }

        private void Order_Load(object sender, EventArgs e)
        {
            this.txtOutput.Text = "Hello, You want to purchase a " + Customer.SetName1 + ".Please pay " + Customer.SetPrice1 + " Tk fast. Thank you.";
            txtOutput.SelectionStart = 0;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            int fixedTk;
            var TK = txtPutPrice.Text;
            int taka;
            Int32.TryParse(Customer.SetPrice1, out fixedTk);
            Int32.TryParse(TK, out taka);
            int finalTk = taka - fixedTk;
            FinalAmount = finalTk.ToString();
            if (finalTk < 0)
            {
                MessageBox.Show("Please enter more amount of Tk.");
            }
            else if(finalTk > 0)
            {
                Purchase pur = new Purchase();
                pur.Show();
                this.Hide();
            }
            else
            {
                Purchase pur = new Purchase();
                pur.Show();
                this.Hide();
            }

        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            Customer cust = new Customer();
            cust.Show();
            this.Hide();
        }
    }
}
