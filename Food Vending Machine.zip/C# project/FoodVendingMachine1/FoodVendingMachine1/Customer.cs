﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class Customer : Form
    {
        public static string SetPrice1 = "";
        public static string SetName1 = "";
        private Info Da { get; set; }
        public Customer()
        {

            InitializeComponent();
            this.Da = new Info();

            pbCocaCola.ImageLocation = @"C:\Users\User\Desktop\C# project\coca-cola.jpg";
            pbDairyMilk.ImageLocation = @"C:\Users\User\Desktop\C# project\dairymilk-removebg.png";
            pbLays.ImageLocation = @"C:\Users\User\Desktop\C# project\lays-removebg.png";
            pbMangoBar.ImageLocation = @"C:\Users\User\Desktop\C# project\mango bar.jpg";
            pbMountainDew.ImageLocation = @"C:\Users\User\Desktop\C# project\MountenDew-removebg.png";
            pbPepsi.ImageLocation = @"C:\Users\User\Desktop\C# project\pepsi-removebg.png";
            pbPotato.ImageLocation = @"C:\Users\User\Desktop\C# project\potato-removebg.png";
            pbSnackess.ImageLocation = @"C:\Users\User\Desktop\C# project\Snickers-removebg.png";
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            LogIn ln = new LogIn();
            ln.Show();
            this.Hide();
        }

        private void btnPotato_Click_1(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-001';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "10";
                SetName1 = "Potato";
                Order buyPotato = new Order();
                buyPotato.Show();
                this.Hide();
            }
        }

        private void btnCola_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-002';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "40";
                SetName1 = "CocaCola";
                Order buyCocaCola = new Order();
                buyCocaCola.Show();
                this.Hide();
            }
        }

        private void btnDairy_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-003';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "165";
                SetName1 = "DairyMilk";
                Order buyDairyMilk = new Order();
                buyDairyMilk.Show();
                this.Hide();
            }
        }

        private void btnLays_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-004';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "65";
                SetName1 = "Lays";
                Order buyLays = new Order();
                buyLays.Show();
                this.Hide();
            }
        }

        private void btnSnackers_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-005';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "50";
                SetName1 = "Snackers";
                Order buySnackers = new Order();
                buySnackers.Show();
                this.Hide();
            }
        }

        private void btnPrice_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-006';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "30";
                SetName1 = "Pepsi";
                Order buyPepsi = new Order();
                buyPepsi.Show();
                this.Hide();
            }
        }

        private void btnDew_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-007';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "35";
                SetName1 = "Mounten Dew";
                Order buyMountenDew = new Order();
                buyMountenDew.Show();
                this.Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var query = "select * from Product where Id = 'P-006';";
            var amount1 = this.Da.ExecuteQuery(query);

            if (amount1.Tables[0].Rows.Count == 1)
            {
                SetPrice1 = "30";
                SetName1 = "mango Bar";
                Order buymangoBar = new Order();
                buymangoBar.Show();
                this.Hide();
            }
        }

        private void btnMainMenu_Click_1(object sender, EventArgs e)
        {
            LogIn ln = new LogIn();
            ln.Show();
            this.Hide();
        }
    }
}
