﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string ut;
            SqlConnection sqlcon = new SqlConnection("Data Source=DESKTOP-PR2ORBP;Initial Catalog=VenderMatchine;Persist Security Info=True;User ID=sa;Password=1234");
            sqlcon.Open();
            SqlCommand sqlcom = new SqlCommand("select Role from UserInfo where Id = '" + txtUserId.Text + "' and Password = '" + txtPassword.Text + "';", sqlcon);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
            DataTable dt = new DataTable();
            sda.Fill(dt);



            if (dt.Rows.Count > 0)
            {
                ut = dt.Rows[0][0].ToString();
                if(ut == "Admin")
                {
                    AdminForm af = new AdminForm();
                    af.Show();
                    this.Hide();
                }
                else if(ut == "Moderator")
                {
                    Moderator moderator = new Moderator();
                    moderator.Show();
                    this.Hide();
                }
                else if(ut == "Editor")
                {
                    Editor editor = new Editor();
                    editor.Show();
                    this.Hide();
                }
                else if (ut == "Customer")
                {
                    Customer cus = new Customer();
                    cus.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Invalid Login Information");
            }

            sqlcon.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }
    }
}
