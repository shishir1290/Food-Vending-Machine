﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachine1
{
    public partial class Product : Form
    {
        private Info Da { get; set; }

        public Product()
        {
            InitializeComponent();
            this.Da = new Info();

            this.PopulateGridView();
            this.dgvProduct.ClearSelection();
        }

        private void PopulateGridView(string sql = "select * from Product;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvProduct.AutoGenerateColumns = false;
            this.dgvProduct.DataSource = ds.Tables[0];
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            this.PopulateGridView();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!IsValidToSaveData())
            {
                MessageBox.Show("Please fill all the information", "Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            try
            {
                if (!this.IsValidToSaveData())
                {
                    MessageBox.Show("Invalid opration. Please fill up all the information");
                    return;
                }

                var query = "select * from Product where Id = '" + this.txtProductId.Text + "';";
                var ds = this.Da.ExecuteQuery(query);

                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    var sql = @"update Product
                            set ProductName = '" + this.txtProductName.Text + @"',
                            Price = " + this.txtPrice.Text + @",
                            ExpiryDate = '" + this.dtpExpiryDate.Text + @"'
                            where Id = '" + this.txtProductId.Text + "';";
                    var count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data updated successfully");
                    else
                        MessageBox.Show("Data upgradation failed");
                }
                else
                {
                    //insert
                    var sql = @"insert into Product values('" + this.txtProductId.Text + "', '" + this.txtProductName.Text + "', " + this.txtPrice.Text + ", '" + this.dtpExpiryDate.Text + "');";
                    var count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show("Data insertion successfull");
                    else
                        MessageBox.Show("Data insertion failed");
                }

                this.PopulateGridView();
                this.RefreshContent();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
            this.dgvProduct.ClearSelection();
        }

        private bool IsValidToSaveData()
        {
            if (String.IsNullOrEmpty(this.txtProductId.Text) ||
                String.IsNullOrEmpty(this.txtProductName.Text) || String.IsNullOrEmpty(this.txtPrice.Text) ||
                String.IsNullOrEmpty(this.dtpExpiryDate.Text) || String.IsNullOrWhiteSpace(this.txtProductId.Text))
            {
                return false;
            }
            else
                return true;
        }

        private void RefreshContent()
        {
            this.txtProductId.Clear();
            this.txtProductName.Clear();
            this.txtPrice.Clear();
            this.dtpExpiryDate.Text="";
            this.txtAutoProductSearch.Clear();
            this.AutoIdGenerate();
        }

        private void txtAutoProductSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from Product where ProductName like '" + txtAutoProductSearch.Text + "%' or Id like '" + txtAutoProductSearch.Text + "%';";
            this.PopulateGridView(sql);
        }
        private void AutoIdGenerate()
        {
            var sql = "select * from Product order by Id desc;";
            var dt = this.Da.ExecuteQueryTable(sql);

            var lastId = dt.Rows[0][0].ToString();
            string[] temp = lastId.Split('-');
            int no = Convert.ToInt32(temp[1]);
            string newId = "P-" + (++no).ToString("d3") ;
            this.txtProductId.Text = newId;
        }

        private void Product_Load(object sender, EventArgs e)
        {
            this.dgvProduct.ClearSelection();
            this.AutoIdGenerate();
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (this.dgvProduct.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please select a row first to delete", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                return;
            }
            if (DialogResult.Yes == MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                try
                {
                    var id = this.dgvProduct.CurrentRow.Cells[0].Value.ToString();
                    var name = this.dgvProduct.CurrentRow.Cells[1].Value.ToString();

                    var sql = "delete from Product where Id = '" + id + "';";
                    int count = this.Da.ExecuteDMLQuery(sql);

                    if (count == 1)
                        MessageBox.Show(name + " has been deleted successfully");
                    else
                        MessageBox.Show("Data deletion failed");

                    this.PopulateGridView();
                }
                catch (Exception exc)
                {
                    MessageBox.Show("An error has occured: " + exc.Message);
                }
            }
            this.dgvProduct.ClearSelection();
        }

        private void dgvProduct_DoubleClick(object sender, EventArgs e)
        {
            this.txtProductId.Text = this.dgvProduct.CurrentRow.Cells["Id"].Value.ToString();
            this.txtProductName.Text = this.dgvProduct.CurrentRow.Cells[1].Value.ToString();
            this.txtPrice.Text = this.dgvProduct.CurrentRow.Cells[2].Value.ToString();
            this.dtpExpiryDate.Text = this.dgvProduct.CurrentRow.Cells[3].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.RefreshContent();
            this.dgvProduct.ClearSelection();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            login.Show();
            this.Hide();
        }
    }
}