﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FoodVendingMachine1
{
    public partial class CloseProgram : Form
    {
        public CloseProgram()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection("Data Source=DESKTOP-PR2ORBP;Initial Catalog=VenderMatchine;Persist Security Info=True;User ID=sa;Password=1234");
            sqlcon.Open();
            SqlCommand sqlcom = new SqlCommand("select * from UserInfo where Id = '" + txtUserId.Text + "' and Password = '" + txtPassword.Text + "';", sqlcon);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Logout Information.");
            }

            sqlcon.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            LogIn ln = new LogIn();
            ln.Show();
            this.Hide();
        }
    }
}
