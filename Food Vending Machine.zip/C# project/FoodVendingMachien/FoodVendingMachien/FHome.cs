﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodVendingMachien
{
    public partial class FHome : Form
    {
        private LogIn Fl { get; set; }
        public FHome()
        {
            InitializeComponent();
        }
        public FHome(LogIn fl, string text) : this()
        {
            this.Fl = fl;
            this.lblUserInfo.Text += text;
        }



        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Logout Confirmed.");
            this.Fl.Show();
        }

       

       
    }
}
