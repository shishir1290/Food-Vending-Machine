﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FoodVendingMachien
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection("Data Source=DESKTOP-PR2ORBP;Initial Catalog=VenderMatchine;Persist Security Info=True;User ID=sa;Password=1234");
            sqlcon.Open();
            SqlCommand sqlcom = new SqlCommand("select * from UserInfo where Id = '"+txtUserId.Text+"' and Password = '"+txtPassword.Text+"';", sqlcon);
            SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            
            

            if ( dt.Rows.Count > 0)
            {
                MessageBox.Show("Login Confirmed.");
                this.Hide();
                FHome fh = new FHome(this, this.txtUserId.Text);

                fh.Show();
            }
            else
            {
                MessageBox.Show("Invalid Login Information");
            }

            sqlcon.Close();
        }

        
    }
}
